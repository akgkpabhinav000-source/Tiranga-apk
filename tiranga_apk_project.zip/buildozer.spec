[app]

# (str) Title of your application
title = Tiranga

# (str) Package name
package.name = tiranga

# (str) Package domain (use your own domain if you publish it)
package.domain = org.example

# (str) Source code directory
source.dir = .

# (str) Application version
version = 1.0

# (str) Supported source file extensions
source.include_exts = py,png,jpg,jpeg,kv,atlas

# (str) Application requirements
requirements = python3,kivy

# (str) Orientation
orientation = portrait

# (bool) Fullscreen
fullscreen = 0

# (str) Android API target
android.api = 35

# (str) Minimum Android API
android.minapi = 21

# (str) Android architecture
android.arch = arm64-v8a

# (bool) Keep app as a single APK
android.private_storage = True

[buildozer]

# (str) Log level
log_level = 2
