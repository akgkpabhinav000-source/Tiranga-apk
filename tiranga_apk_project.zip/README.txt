TIRANGA APK PROJECT

Files:
- main.py              Kivy version of the uploaded Tkinter program
- buildozer.spec       Buildozer configuration

BUILD ON LINUX/WSL:
1. Install Python 3, pip, and Buildozer.
2. In this folder run:
   pip install buildozer
   buildozer android debug
3. After a successful build, the APK will be in the bin/ folder.

IMPORTANT:
The original program uses Tkinter, which is desktop GUI code. main.py is the Android/Kivy conversion.
