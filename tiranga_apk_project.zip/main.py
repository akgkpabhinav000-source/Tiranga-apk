from kivy.app import App
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle, Ellipse, Line
from math import sin, cos, radians


class FlagWidget(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bind(size=self.draw_flag, pos=self.draw_flag)
        self.draw_flag()

    def draw_flag(self, *args):
        self.canvas.clear()

        w, h = self.size
        x, y = self.pos

        # Keep the same 600:400 aspect ratio as the original program.
        flag_w = w
        flag_h = min(h, flag_w * 400 / 600)
        flag_w = min(flag_w, flag_h * 600 / 400)

        left = x + (w - flag_w) / 2
        bottom = y + (h - flag_h) / 2
        band_h = flag_h / 3

        with self.canvas:
            # Saffron band
            Color(1.0, 0.6, 0.2, 1)
            Rectangle(pos=(left, bottom + 2 * band_h),
                      size=(flag_w, band_h))

            # White band
            Color(1, 1, 1, 1)
            Rectangle(pos=(left, bottom + band_h),
                      size=(flag_w, band_h))

            # Green band
            Color(0.0745, 0.5333, 0.0314, 1)
            Rectangle(pos=(left, bottom),
                      size=(flag_w, band_h))

            # Ashoka Chakra
            cx = left + flag_w / 2
            cy = bottom + flag_h / 2
            radius = band_h * 0.49

            # Outer white circle / blue outline
            Color(1, 1, 1, 1)
            Ellipse(pos=(cx - radius, cy - radius),
                    size=(2 * radius, 2 * radius))

            Color(0.0, 0.0, 0.502, 1)
            Line(circle=(cx, cy, radius), width=2.2)

            # 24 spokes, matching the original Python program
            for i in range(24):
                angle = radians(i * 15)
                start_r = radius / 7
                sx = cx + start_r * cos(angle)
                sy = cy + start_r * sin(angle)
                ex = cx + radius * cos(angle)
                ey = cy + radius * sin(angle)
                Line(points=(sx, sy, ex, ey), width=1.4)

            # Small blue center circle
            center_r = radius / 7
            Ellipse(pos=(cx - center_r, cy - center_r),
                    size=(2 * center_r, 2 * center_r))


class TirangaApp(App):
    def build(self):
        self.title = "Flag of India"
        return FlagWidget()


if __name__ == "__main__":
    TirangaApp().run()
